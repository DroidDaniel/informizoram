$(document).ready(function () {
  $(".nav_menu").click(function () {
    $(".navbar").toggleClass("navbar_mob");
  });
});
